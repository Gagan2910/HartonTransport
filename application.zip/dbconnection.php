<?php

$servername="myfirstdatabase.cxposoytvcjq.us-east-2.rds.amazonaws.com";//"harton.mysql.database.azure.com";
$username="Harry";//"gagan@harton";
$userPassword="Harry$20";//"Harry$20";
$database="hartontransport";//"hartontransport";

$connection= mysqli_connect($servername,$username,$userPassword,$database,3306);
?>


 

 