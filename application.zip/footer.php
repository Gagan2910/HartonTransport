
</td></tr>
<tr><td colspan=2 class="footer">
<div><div class="column"><h5><a href="index.php">About</a></h5><h6></h6></div><div class="column"><h5><a href="services.php">Services</a></h5><h6>Freight Delivery<br>Import-Export<br>
Custom Clearance<br>House moving<br>Courier Services</h6>
</div><div class="column middle"><h5><a href="stafflogin.php">Stafflogin</a></h5><h6></h6></div><div class="column"><h5><a href="customerregister.php">Customer</a></h5><h6>Register<br>Login</h6></div><div class="column"><h5><a href="contact.php">Contactus</a></h5><h6>Location:<br>6/19 Roanoke Way<br>Albany <br>Auckland 1000<br>New Zealand</h6></div></div>
<div><h6>Follow us:<br><br><img src="images/facebook.jpg" hspace=6><img src="images/instagram.jpg" hspace=6><img src="images/twitter.jpg" hspace=6><img src="images/whatsapp.jpg" hspace=6><br>copyright@2018gagandeepkaur</h6></div>
</td></tr>
</table>

</body>

</html>